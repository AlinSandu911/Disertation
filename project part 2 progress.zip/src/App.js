import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Bar, Line, Pie } from 'react-chartjs-2';
import 'chart.js/auto';
import './App.css';

const skillIconMap = {
  1: 'skill_level_1.png',
  2: 'skill_level_2.png',
  3: 'skill_level_3.png',
  4: 'skill_level_4.png',
  5: 'skill_level_5.png',
  6: 'skill_level_6.png',
  7: 'skill_level_7.png',
  8: 'skill_level_8.png',
  9: 'skill_level_9.png',
  10: 'skill_level_max.png',
};

function App() {
  const [nickname, setNickname] = useState('');
  const [playerData, setPlayerData] = useState(null);
  const [searchHistory, setSearchHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [theme, setTheme] = useState('light');
  const [historyData, setHistoryData] = useState([]);

  // Fetch player stats
  const fetchStats = async () => {
    if (!nickname) return;
    setLoading(true);
    setErrorMsg('');

    try {
      const response = await axios.get(`http://localhost:5000/player/${nickname}`);
      if (response.data && response.data.nickname) {
        setPlayerData(response.data);
        updateSearchHistory(nickname);
      } else {
        setErrorMsg('Invalid player data received.');
        setPlayerData(null);
      }
    } catch (error) {
      console.error('Fetch error:', error.message);
      setErrorMsg('Player not found or API error.');
      setPlayerData(null);
    } finally {
      setLoading(false);
    }
  };

  // Fetch history
  const fetchHistory = async () => {
    if (!nickname) return;
    try {
      const response = await axios.get(`http://localhost:5000/history/${nickname}`);
      setHistoryData(response.data);
    } catch (error) {
      console.error('Error fetching history:', error);
    }
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      setTheme(savedTheme);
    }
    const history = JSON.parse(localStorage.getItem('searchHistory')) || [];
    setSearchHistory(history);
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
  };

  const updateSearchHistory = (name) => {
    const filtered = searchHistory.filter((n) => n !== name);
    const updatedHistory = [name, ...filtered];
    if (updatedHistory.length > 5) {
      updatedHistory.pop();
    }
    setSearchHistory(updatedHistory);
    localStorage.setItem('searchHistory', JSON.stringify(updatedHistory));
  };

  const numericResults = playerData?.recent_matches?.map((r) => (r === 'W' ? 1 : 0)) || [];
  const chartData = {
    labels: playerData?.recent_matches?.map((_, idx) => `Match ${idx + 1}`) || [],
    datasets: [
      {
        label: 'Recent Results',
        data: numericResults,
        backgroundColor: numericResults.map((val) => (val === 1 ? 'green' : 'red')),
      },
    ],
  };

  // Elo progression chart data
  const eloData = {
    labels: playerData?.elo_progression?.map((entry) => entry.date) || [], // assuming you have dates for Elo progression
    datasets: [
      {
        label: 'Elo Progression',
        data: playerData?.elo_progression?.map((entry) => entry.elo) || [],
        fill: false,
        borderColor: 'rgba(75,192,192,1)',
        tension: 0.1,
      },
    ],
  };

  // Win rate pie chart data
  const winRateData = {
    labels: ['Wins', 'Losses'],
    datasets: [
      {
        data: [
          numericResults.filter((result) => result === 1).length, // Wins
          numericResults.filter((result) => result === 0).length, // Losses
        ],
        backgroundColor: ['#36A2EB', '#FF5733'],
        hoverOffset: 4,
      },
    ],
  };

  return (
    <div className={`app-container ${theme}-theme`}>
      <h1>Gaming Performance Tracker</h1>

      <button className="theme-toggle-btn" onClick={toggleTheme}>
        Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode
      </button>

      <div className="card">
        <input
          type="text"
          value={nickname}
          placeholder="Enter player nickname"
          onChange={(e) => setNickname(e.target.value)}
        />
        <button onClick={fetchStats}>Search</button>
        <button onClick={fetchHistory}>View History</button>

        {/* Loading spinner for player data */}
        {loading && !playerData && <div className="spinner">Loading Player Stats...</div>}

        {/* Show player data if fetched */}
        {playerData && (
          <div className="player-info">
            <h2>{playerData.nickname}</h2>

            {/* Display flag if available */}
            {playerData.country ? (
              <img
                src={`https://flagcdn.com/24x18/${playerData.country.toLowerCase()}.png`}
                alt={`Flag of ${playerData.country}`}
                className="player-flag"
              />
            ) : (
              <span>No flag available</span>
            )}

            {/* Display avatar */}
            {playerData.avatar && (
              <img
                src={playerData.avatar}
                alt={`${playerData.nickname} avatar`}
                className="player-avatar"
              />
            )}

            {/* Display Faceit Profile Link */}
            {playerData.profile_link && (
              <a href={playerData.profile_link} target="_blank" rel="noopener noreferrer">
                Visit {playerData.nickname}'s Faceit Profile
              </a>
            )}

            <div className="level-icon-section">
              <p>Skill Level: {playerData.skill_level}</p>
              {skillIconMap[playerData.skill_level] && (
                <img
                  src={skillIconMap[playerData.skill_level]}
                  alt={`Level ${playerData.skill_level} icon`}
                  className="level-icon"
                />
              )}
            </div>

            <p>Elo: {playerData.faceit_elo}</p>
            <p>Total Matches: {playerData.total_matches}</p>
            <p>Win Rate: {playerData.win_rate}%</p>
            <p>Current Win Streak: {playerData.win_streak}</p>

            <div className="chart-wrapper">
              <h3>Recent Match Results</h3>
              <Bar data={chartData} />
            </div>

            {/* Elo Progression Chart */}
            {playerData.elo_progression && (
              <div className="chart-wrapper">
                <h3>Elo Progression</h3>
                <Line data={eloData} />
              </div>
            )}

            {/* Win Rate Pie Chart */}
            {numericResults.length > 0 && (
              <div className="chart-wrapper">
                <h3>Win Rate</h3>
                <Pie data={winRateData} />
              </div>
            )}
          </div>
        )}

        {/* Error handling */}
        {errorMsg && (
          <div className="error-message">
            <p>{errorMsg}</p>
            <button onClick={fetchStats}>Retry</button>
          </div>
        )}

        <div className="history">
          <h3>Search History</h3>
          <ul>
            {searchHistory.map((name, idx) => (
              <li
                key={idx}
                onClick={() => {
                  setNickname(name);
                  fetchStats();
                }}
              >
                {name}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <h2>History</h2>
      {historyData.map((record) => (
        <div key={record.id} style={{ border: '1px solid #ccc', margin: '10px', padding: '10px' }}>
          <p>Fetched At: {record.fetchedAt}</p>
          <p>Elo: {record.faceit_elo}</p>
          <p>Skill Level: {record.skill_level}</p>
          <p>Total Matches: {record.total_matches}</p>
          <p>Win Rate: {record.win_rate}%</p>
          <p>Current Win Streak: {record.win_streak}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
