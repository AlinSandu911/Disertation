// server.js
require('dotenv').config({ path: './apikey.env' }); // Specify the path to your apikey.env file
const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
const PORT = 5000;

// Use the API key from the environment variable
const FACEIT_API_KEY = process.env.FACEIT_API_KEY;

if (!FACEIT_API_KEY) {
  console.error('API key is missing!');
  process.exit(1);
}

app.use(cors());

// Get real player data
app.get('/player/:nickname', async (req, res) => {
  const { nickname } = req.params;

  try {
    // 1. Get basic player info (like ID, Elo, avatar, etc.)
    const playerResponse = await axios.get(`https://open.faceit.com/data/v4/players?nickname=${nickname}`, {
      headers: {
        Authorization: `Bearer ${FACEIT_API_KEY}`
      }
    });

    if (!playerResponse.data) {
      return res.status(404).json({ message: 'Player not found' });
    }

    const player = playerResponse.data;

    // 2. Get CS2 stats for that player
    const statsResponse = await axios.get(`https://open.faceit.com/data/v4/players/${player.player_id}/stats/cs2`, {
      headers: {
        Authorization: `Bearer ${FACEIT_API_KEY}`
      }
    });

    if (!statsResponse.data) {
      return res.status(404).json({ message: 'Player stats not found' });
    }

    const stats = statsResponse.data;

    // 3. Parse recent results (1 = win, 0 = loss)
    const recentRaw = stats.lifetime['Recent Results'] || [];
    const recentMatches = recentRaw.map(r => r === '1' ? 'W' : 'L');

    // 4. Calculate win streak
    let winStreak = 0;
    for (let i = 0; i < recentRaw.length; i++) {
      if (recentRaw[i] === '1') {
        winStreak++;
      } else {
        break;
      }
    }

    // Construct the player's profile link dynamically
    const profileLink = `https://www.faceit.com/en/players/${nickname}`;

    const playerData = {
      nickname: player.nickname,
      faceit_elo: player?.games?.cs2?.faceit_elo || 'N/A',
      skill_level: player?.games?.cs2?.skill_level || 'N/A',
      avatar: player.avatar,
      total_matches: stats.lifetime['Matches'] || 0,
      win_rate: stats.lifetime['Win Rate %'] || 'N/A',
      win_streak: winStreak,
      recent_matches: recentMatches,
      profile_link: profileLink // Include the dynamically generated profile link
    };

    res.json(playerData);
  } catch (error) {
    console.error('Error fetching data:', error?.response?.data || error.message);
    res.status(500).json({ message: 'Server error, try again later' });
  }
});

// Get history (still mocked for now)
app.get('/history/:nickname', (req, res) => {
  const history = [
    {
      id: '1',
      fetchedAt: new Date().toISOString(),
      faceit_elo: 918,
      skill_level: 4,
      total_matches: 200,
      win_rate: 52,
      win_streak: 2
    },
    {
      id: '2',
      fetchedAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
      faceit_elo: 910,
      skill_level: 4,
      total_matches: 198,
      win_rate: 51,
      win_streak: 1
    }
  ];

  res.json(history);
});

// Optional root
app.get('/', (req, res) => {
  res.send(`<h2>🎮 Faceit Stats API is running</h2><p>Try /player/DonAntonioX</p>`);
});

app.listen(PORT, () => {
  console.log(`✅ Server is running at http://localhost:${PORT}`);
});
